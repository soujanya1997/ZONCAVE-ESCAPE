# Zoncave-Escape
Virtual Reality 3D Creepy Game , made using unity3D Game Engine. 


Lost in the Virtual Creepy World of Zombies, Find the key for way to home and feel many other KindOf real adventures in front of your eyes , which generally one can only see in horror shows . Here its Virtualy created in front of your eyes . Your head movements let you see through entire world i.e. 360* rotation (Imagine :P) . Hence the Idea is to play for your health and home, Kill zombies using Gun Provided.


Devices used ---> VR HeadSet, Contoller .

Platform supported by game ---> Windows , Android 5.0(and above) .


Rules For Playing Game:
1.use Arrow keys to move.
2.use ctrl key to shoot.
3.find the key then go to your home.
4. Beware of the Zombies.
5. Crystals increases your health.
6. Use touchpad using one finger for head movements.


link for exe file of Application:
https://drive.google.com/open?id=1K9H1NG1HBwc8H8Quh5nlofpOdgxmuShF
